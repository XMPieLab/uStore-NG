import React, { Component, useState } from 'react'
import './styles/sample.scss'

class Sample extends Component {
  constructor (props) {
    super(props)

    this.state = {
      inputValue: '',
    }
  }

  componentDidMount() {
    const {  value } = this.props

    this.setState({
      inputValue: value,
    })
  }

  onInputChanged = (e) => {
    const newValue = e.target.value
    const isNumber = !isNaN(parseInt(newValue))

    const parsedValue = (this.state.type === 'number') && newValue && isNumber ? Number(newValue) : newValue

    this.setState({inputValue: parsedValue})
    this.props.onChange(parsedValue)
  }

  handleOnBlur = () => {
    const { onBlur, id } = this.props

    onBlur(id, this.state.inputValue)
  };

  render () {
    const { options = {
      readonly: false
    },
      disabled,
      required,
      readonly
    } = this.props

    const { inputValue, type } = this.state

    return (
      <div>
        <input
          type={type}
          required={required}
          onChange={this.onInputChanged}
          className='sample-duc form-control'
          value={inputValue}
          disabled={readonly || options.readonly || disabled}
          onBlur={this.handleOnBlur}
        />
      </div>
    )
  }
}

if (typeof window !== 'undefined') {
  window.uStoreDucs = window.uStoreDucs || []
  window.uStoreDucs.push({ name: 'Sample', component: Sample, displayName: 'Sample duc name', configSample: {
      sampleText: 'Sample text',
    }
  })
}

export default Sample
