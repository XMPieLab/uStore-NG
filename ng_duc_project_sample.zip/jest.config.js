const { defaults } = require('jest-config')

module.exports = {
  verbose: true,
  testURL: 'http://localhost',
  moduleFileExtensions: [...defaults.moduleFileExtensions, 'js', 'ts', 'tsx'],
  setupFilesAfterEnv: ['<rootDir>/jestConfig.js'],
  transformIgnorePatterns: ['<rootDir>/node_modules/'],
  testEnvironment: 'jsdom',
  moduleNameMapper: {
    '\\.(css|less|scss|sass)$': 'identity-obj-proxy',
    "^.+\\.svg$": '<rootDir>/tests/svgTransformer.js',
    '^tests\\/(.*)$': '<rootDir>/tests/$1',
    '\\$ducs/(.*)$': '<rootDir>/$1'
  },
  collectCoverage: true,
  collectCoverageFrom: [
    '<rootDir>/*.js',
    '!<rootDir>/tests/**',
    '!<rootDir>/coverage/**',
    '!<rootDir>/dev/**',
    '!<rootDir>/dist_dev/**',
    '!<rootDir>/node_modules/**'
  ]
}
