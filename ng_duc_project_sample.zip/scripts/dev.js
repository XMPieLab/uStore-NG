const glob = require('glob-promise')
const path = require('path')
const fs = require('fs')
const clc = require("cli-color")
const relpath = path.join.bind(path, __dirname)
const spawn = require('cross-spawn')
const moment = require('moment')

const currentTime = () => moment().format('DD/MM/YYYY hh:MM:ss:mmm')

const runDucNpm = (file, libraryName) => {
  const f = fs.readFileSync(path.resolve(__dirname, '../webpack.config.js'), 'utf-8')
  const webpackConfig = f.replaceAll('___ENTRY_NAME___', file).replaceAll('___LIBRARY_NAME___', libraryName)
  const webpackConfigPath = path.resolve(__dirname, `../build_configs/webpack_${libraryName}.config.js`)

  fs.writeFileSync(webpackConfigPath, webpackConfig)

  console.log(clc.blue(`[${currentTime()}]`), clc.yellow(`[Compiling ${libraryName}]`))

  const npm = spawn('./node_modules/.bin/webpack', ['--color', '--watch', '--config', webpackConfigPath])
  npm.stdout.on('data', (data) => {
    console.log(clc.blue(`[${currentTime()}]`), clc.yellow(`[${libraryName}]`))
    console.log(clc.whiteBright(data))
  })
  npm.stderr.on('data', (data) => {
    if (`${data}`.startsWith('[BABEL] Note: ')) {
      console.log(clc.blackBright(data))
    } else {
      console.log(clc.red(data))
    }
  });
 ['beforeExit', 'exit'].forEach(eventName => process.on(eventName, () => npm.kill(-9)))

}

const compile = async () => {
  const files = await glob('*.duc.js', {cwd: relpath('../')})

  return files.map(file => {
    const libraryName = file.replace(/\.duc\.js$/, '')
    return  {
      duc: file,
      libraryName
    }
  })
}

const main = async () => {
  if (!fs.existsSync(path.resolve(__dirname, '../build_configs'))) {
    fs.mkdirSync(path.resolve(__dirname, '../build_configs'))
  }
  const ducsList = await compile()

  for (const d of ducsList) {
    const {libraryName, duc} = d
    runDucNpm(duc, libraryName)
  }
}

const run = async () => {
  await main()
}

run()
