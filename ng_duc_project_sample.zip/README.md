# Developing DUC for uStore NG

### Prerequisites
* Use node js version 16 and above.

###To develop a DUC follow these steps

1. Create legacy custom DUC in your uStore server.
2. Download the ng_duc_project_sample.zip file from [here](http://www.google.com]).
3. Extract the downloaded zip to a new directory.
4. In the new directory do `npm install`.
5. In the new directory rename Sample.duc.js to a new name (Name should start with a capital letter and end with .duc.js suffix)
6. Inside the file change:
   1. Change the class name (lets say NewNameOfDuc)
   2. Locate these lines
    ```
    if (typeof window !== 'undefined') {
    window.uStoreDucs = window.uStoreDucs || []
    window.uStoreDucs.push({ name: 'Sample', component: Sample, displayName: 'Sample duc name' })
    }
    
    export default Sample
    ```
   3. Change `name: 'Sample'` to `name: 'NewNameOfDuc'` (Name should have no spaces)
   4. Change `component: Sample` to `component: NewClassName`
   5. Change `displayName: 'Sample duc name'` to ` displayName: 'New DUC display name'`. The display name will be display in property edit beside the default DUCs.
   6. Change `export default Sample` to `export default NewNameOfDuc`
7. In the terminal run `npm run build` when script is done you will find a zip file in `dist` directory. The file should be named NewClassName.zip.
8. Register the new DUC in uStore admin. (TBD tool location)
9. Create a new property in your product and select the new custom DUC.
10. In the theme directory start development by `npm start -- ducbuild=/path/to/duc/directory`
11. You can now modify the files inside the DUC's directory. Note that when you update the DUC's files will be compiled but the application will not be reloaded
    in the browser, you will need to do it manually.

### DUC development guide lines
1. DUC should be treated as an independent component and should not expect libraries to be present. Install packages you need to use.
2. DUC parameters will provide only the data that is related to the DUC and not a global model from uStore.
3. For changes to take effect you need to call `this.props.onChange(newValue)` or `this.props.onBlue(this.props.id, newValue)` in case of focus lost.
4. DUC should take into account `readonly`, `required`, `disabled` props to behave correctly and be influenced by the form.
5. The DUC will accept `uiSchema` and `jsonschema` are parameters that describe the configuration and validation of the DUC by the form. See [json-schema.org](https://json-schema.org/) to understand the format.
