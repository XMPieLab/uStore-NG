import React from 'react'

import './Button.css'

export function Button( props ) {
  const {
    children, className, style, to,
  } = props

  return (
    <a
      className={`xw-homepage-banner-button-cta truncate ${className}`}
      href={to || '#'}
      style={style}
    >
      { children }
    </a>
  )
}

Button.defaultProps = {
  className: '',
}
