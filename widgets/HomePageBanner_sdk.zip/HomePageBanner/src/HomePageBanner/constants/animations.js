export const titleAnimations = {
  1: 'fadeiup1',
  2: 'bounceid1',
  3: 'slideil1',
}

export const subTitleAnimations = {
  1: 'fadeir2',
  2: 'fadeil2',
  3: 'fadeid2',
}

export const ctaAnimations = {
  1: 'bounceid4',
  2: 'bounceiup4',
  3: 'bounceil4',
}
