import React, { useState } from 'react'

import { HomePageBanner } from '../components/HomePageBanner.js'

import 'swiper/css'
import 'swiper/css/pagination'
import 'swiper/css/navigation'
import '../HomePageBanner.css'

export function HomePageBannerContainer( { configState } ) {
  const [activeSlide, setActiveSlide] = useState( 0 )

  const handleSlideChange = ( swiper ) => {
    setActiveSlide( swiper.activeIndex )
  }

  return (
    <HomePageBanner
      activeSlide={activeSlide}
      configState={configState}
      handleSlideChange={handleSlideChange}
    />
  )
}
