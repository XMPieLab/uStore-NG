import React from 'react'
import ReactDOM from 'react-dom'
import Widget from './index.widget.js'

ReactDOM.render( <Widget />, document.getElementById( 'root' ) )
