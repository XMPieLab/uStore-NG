import React from 'react'

import { WrapperTextUnitsOfMeasure } from './WrapperTextUnitsOfMeasure.js'

export const TextPacksUnitsOfMeasure = ( { slide } ) => (
  <WrapperTextUnitsOfMeasure>
    {
      `${slide.MinimumQuantity === 1
        ? `Sold in ${slide.Unit.PackType.PluralName} `
        : `Per ${slide.MinimumQuantity} ${slide.Unit.PackType.PluralName} `

      }(${slide.Unit.ItemQuantity} ${slide.Unit.ItemType.PluralName}/${slide.Unit.PackType?.Name}}`
    }
  </WrapperTextUnitsOfMeasure>
)
