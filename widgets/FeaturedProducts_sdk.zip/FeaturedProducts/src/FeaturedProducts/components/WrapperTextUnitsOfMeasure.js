import React from 'react'

export const WrapperTextUnitsOfMeasure = ( props ) => {
  const { children } = props
  return (
    <p className="xw-featured-products-text-units-of-measure xw-featured-products-reset-margin">
      {children}
    </p>
  )
}
