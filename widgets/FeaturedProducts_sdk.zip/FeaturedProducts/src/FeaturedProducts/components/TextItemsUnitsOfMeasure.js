import React from 'react'

import { WrapperTextUnitsOfMeasure } from './WrapperTextUnitsOfMeasure.js'

export const TextItemsUnitsOfMeasure = ( { slide } ) => (
  <WrapperTextUnitsOfMeasure>
    {
      slide.MinimumQuantity > 1
        ? `Per ${slide.MinimumQuantity} ${slide.Unit.ItemType?.PluralName}` : ''
    }
  </WrapperTextUnitsOfMeasure>
)
