import React, { useEffect, useRef, useState } from 'react'
import AdobeLogo from './images/Adobe_Express_logo_RGB_256px.svg'
import '../styles/index.widget.css'

const defaultWidgetConfig = {
    'Comment': 'This widget can be added only to Easy Upload products, and it currently doesn\'t support mobile browsers',
    'Name': 'XMPIE_ADOBE_EXPRESS',
    'Adobe app name': 'Adobe App',
    'Adobe API key': '',
    'Button Text': 'Create design',
    'Subtitle text': 'Create your design on Adobe Express.\nIf you don’t have an account, sign up for free.',
    'Edit Button Text': 'Edit',
    'Clear Button Text': 'Clear',
    'Titles in Adobe Express': 'Save & Back to store',
    'showFileUpload': true
}

const mergeConfig = (newConfig, defaultConfig) => {
    const result = {};
    for (const key in defaultConfig) {
        const defaultValue = defaultConfig[key];
        let value = newConfig[key];
        if (value === undefined || value === null || (typeof value === "string" && value.trim() === "")) {
            result[key] = defaultValue;
            continue;
        }
        if (typeof defaultValue === "boolean" && typeof value === "string") {
            if (value.toLowerCase() === "true") value = true;
            else if (value.toLowerCase() === "false") value = false;
            else value = defaultValue;
        }
        if (typeof defaultValue === "number" && typeof value === "string" && !isNaN(Number(value))) {
            value = Number(value);
        }
        result[key] = value;
    }
    return result;
};


const IndexWidget = ({config, uStoreProvider, actions, data}) => {

    if (!actions || !actions.uploadEasyUploadFile) return null

    const configState  = mergeConfig(JSON.parse(config), defaultWidgetConfig)

    const {
        uploadEasyUploadFile,
        setIsDocumentLoading,
        setUploadError,
        setDocumentLoaded,
        setUploadErrorMessage,
        setFileName,
        setViewerState,
        onFormChange,
        setDefault,
        setDropZoneHidden
    } = actions
    const {
        orderItem,
        viewerState,
        product,
        documentLoaded,
        pdfLoader,
        properties
    } = data
    const editorRef = useRef(null)
    const [adobeProductId, setAdobeProductId] = useState(null)

    const propertyKey = Object.keys(properties).find(key => properties[key].custom?.code === 'FileAttachment')
    const propertyID = properties && properties[propertyKey]?.custom?.id
    const isAdobeExpressHidden = properties && Object.values(properties).some((prop) => prop.title === "hideAdobeExpressWidget" && prop.value === "1")

    useEffect(() => {
        setDropZoneHidden(!configState.showFileUpload)
        window.UStoreProvider.state.customState.delete("externalImageLoaded")
        const loadEditor = async () => {
            if (!window.CCEverywhere && configState["Adobe API key"] && !isAdobeExpressHidden) {
                const script = document.createElement('script')
                script.src = 'https://cc-embed.adobe.com/sdk/v4/CCEverywhere.js'
                script.async = false
                script.onload = async () => {
                    const {editor} = await express_Init()
                    editorRef.current = editor
                }
                document.head.appendChild(script)
            }
            if (!editorRef.current && window.__cc_everywhere_sdk__) {
                editorRef.current = window.__cc_everywhere_sdk__.editor
            }
        }
        !isAdobeExpressHidden && loadEditor()
    }, [config])

    const base64ToFile = (data, fileName) => {
        const [header, base64] = data.split(',')
        const mimeMatch = header.match(/data:(.*?);base64/)
        const mime = mimeMatch ? mimeMatch[1] : 'application/octet-stream'
        const binaryStr = atob(base64.replace(/\s/g, ''))
        const len = binaryStr.length
        const uint8Array = new Uint8Array(len)
        for (let i = 0; i < len; i++) {
            uint8Array[i] = binaryStr.charCodeAt(i)
        }
        return new File([uint8Array], fileName, {type: mime})
    }

    const express_Init = async () => {
        const apiKey = configState["Adobe API key"]
        const appName = configState['Adobe app name']
        const initializeParams = {
            clientId: apiKey,
            appName: appName,
        }
        const configParams = {}
        return await window.CCEverywhere.initialize(
            initializeParams,
            configParams,
        )
    }
    const express_Create = (editor) => {
        const docConfig = {}
        const appConfig = getAppConfig()
        const exportConfig = getExportConfig()
        const containerConfig = getContainerConfig()
        editor.create(docConfig, appConfig, exportConfig, containerConfig)
    }
    const express_Edit = (projectId, editor) => {
        if (!projectId) {
            throw new Error('No project ID provided for editing')
        }
        const docConfig = {documentId: projectId}
        const appConfig = getAppConfig()
        const exportConfig = getExportConfig()
        const containerConfig = getContainerConfig()
        editor.edit(docConfig, appConfig, exportConfig, containerConfig)
    }

    const saveAndDisplayDocument = async (localData) => {
        const { dataType, type, data, fileName } = localData.asset
        if (adobeProductId) {
            await clearPreview({},true)
        }
        if (dataType === 'base64') {
            const uploadedFile = base64ToFile(data, `${fileName}.${type}`)
            setIsDocumentLoading(true)
            const response = await uploadEasyUploadFile(setIsDocumentLoading, '', orderItem, propertyID, setUploadError, setDocumentLoaded, setUploadErrorMessage, uploadedFile, setFileName, setViewerState, viewerState, product)
            if (response?.length && response[0].FileInfoList?.length) {
                delete response[0].FileInfoList[0].MetaData
            }
            onFormChange && onFormChange(propertyKey, response, [])
            window.UStoreProvider.state.customState.set("externalImageLoaded", true)
            setAdobeProductId(localData.documentId)
        }
    }

    const getCallbacks = () => {
        return {
            onCancel: () => {
            },
            onPublish: (intent, publishParams) => {
                const localData = {
                    documentId: publishParams.documentId,
                    asset: publishParams.asset[0],
                }
                saveAndDisplayDocument(localData)
            },
            onError: (err) =>
                console.error('Error received is', err.toString()),
        }
    }

    const getAppConfig = () => {
        return {
            callbacks: getCallbacks(),
            multiPage: true,
            allowedFileTypes: ['application/pdf'],
        }
    }

    const getExportConfig = () => {
        return [
            {
                id: 'download',
                label: 'Download',
                action: {target: 'download'},
                style: {uiType: 'button'},
            },
            {
                id: 'save-modified-asset',
                label: configState['Titles in Adobe Express'],
                action: {target: 'publish'},
                style: {uiType: 'button'},
            },
        ]
    }

    const getContainerConfig = () => {
        return {showLoader: true, zIndex: 4}
    }

    const createEditor = async () => {
        const editor = editorRef.current
        editor && await express_Create(editor)
    }

    const edit = async () => {
        if (!adobeProductId) return
        const editor = editorRef.current
        await express_Edit(adobeProductId, editor)
    }

    const clearPreview = async (e, clearBeforeUpdate) => {
        pdfLoader.clear()
        setUploadError(true)
        setDocumentLoaded(false)
        setDefault()
        !clearBeforeUpdate && window.UStoreProvider.state.customState.delete("externalImageLoaded")
        let fileAttachmentPropData = Object.values(properties).find((prop) => prop?.custom?.code === 'FileAttachment')
        if (fileAttachmentPropData?.value) {
            fileAttachmentPropData = JSON.parse(fileAttachmentPropData.value)
        }
        const deleteFileName = fileAttachmentPropData && fileAttachmentPropData[0] && fileAttachmentPropData[0].FileName
        const fileURIToDelete = deleteFileName && `fileNames=${encodeURIComponent(deleteFileName)}`
        deleteFileName && await UStoreProvider.api.orders.deleteFiles(orderItem.ID, propertyID, fileURIToDelete)
        setAdobeProductId(null)
        onFormChange(propertyKey, [], [])
    }

    if (!JSON.parse(config)["Adobe API key"] || isAdobeExpressHidden) return

    if (documentLoaded && adobeProductId) {
        return (
            <div className={'adobe-widget-buttons'}>
                <button onClick={clearPreview} className={'adobe-clear button button-secondary'}>{configState['Clear Button Text']}</button>
                <button onClick={edit} className={'adobe-edit button button-primary'}>{configState['Edit Button Text']}</button>
            </div>
        )
    }

    if (!documentLoaded && !adobeProductId) {
        return (
            <div className={`adobe-widget ${!configState.showFileUpload ? 'full-size' : ''}`}>
                <AdobeLogo width={73} height={71} className="adobe-logo" onClick={createEditor}/>
                <button className={'create-button button button-primary'} onClick={createEditor}>{configState['Button Text']}</button>
                <div className={'subtitle-text'}>{configState['Subtitle text']}</div>
            </div>
        )
    }

}

export default IndexWidget



