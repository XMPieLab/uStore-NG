import React, { useEffect, useState } from 'react'
import AdobeLogo from './images/Adobe_Express_logo_RGB_256px.svg'
import '../styles/index.widget.css'

const defaultWidgetConfig = {
    'Comment': 'This widget can be added only to Easy Upload products, and it currently doesn\'t support mobile browsers',
    'Name': '',
    'Adobe app name': '',
    'Adobe API key': '',
    'Button Text': 'Create with Adobe Express',
    'Subtitle text': 'Create your design on Adobe Express.\nIf you don’t have an account, sign up for free.',
    'Edit Button Text': 'Edit',
    'Clear Button Text': 'Clear',
    'Titles in Adobe Express': 'Save & Back to store',
    'showFileUpload': true,
    'Adobe Handler URL override': '',
    'API Base URL override': ''
}

const mergeConfig = (newConfig, defaultConfig) => {
    const result = {};
    for (const key in defaultConfig) {
        const defaultValue = defaultConfig[key];
        let value = newConfig[key];
        if (value === undefined || value === null || (typeof value === "string" && value.trim() === "")) {
            result[key] = defaultValue;
            continue;
        }
        if (typeof defaultValue === "boolean" && typeof value === "string") {
            if (value.toLowerCase() === "true") value = true;
            else if (value.toLowerCase() === "false") value = false;
            else value = defaultValue;
        }
        if (typeof defaultValue === "number" && typeof value === "string" && !isNaN(Number(value))) {
            value = Number(value);
        }
        result[key] = value;
    }
    return result;
};


// Module-level flag — survives component unmount/remount cycles
let previewLoadingFlag = false

const IndexWidget = ({config, uStoreProvider, actions, data, context}) => {

    if (!actions || !actions.uploadEasyUploadFile) return null

    const configState  = mergeConfig(JSON.parse(config), defaultWidgetConfig)

    const {
        setUploadError,
        setDocumentLoaded,
        setViewerState,
        onFormChange,
        setDefault,
        setDropZoneHidden,
        pushPropertiesToServer
    } = actions
    const {
        orderItem,
        product,
        documentLoaded,
        pdfLoader,
        properties
    } = data
    const propertyKey = Object.keys(properties).find(key => properties[key].custom?.code === 'FileAttachment')
    const propertyID = properties && properties[propertyKey]?.custom?.id
    const isAdobeExpressHidden = properties && Object.values(properties).some((prop) => prop.title === "hideAdobeExpressWidget" && prop.value === "1")

    // Restore projectId from file properties (survives page refresh)
    const getPersistedProjectId = () => {
        try {
            const prop = Object.values(properties).find((p) => p?.custom?.code === 'FileAttachment')
            if (prop?.value) {
                const files = JSON.parse(prop.value)
                const file = files?.find(f => f.MetaData?.ExternalID)
                return file?.MetaData?.ExternalID || null
            }
        } catch (e) {
            console.error('[AdobeWidget] getPersistedProjectId error:', e)
        }
        return null
    }

    const urlSearchParams = new URLSearchParams(window.location.search)
    const urlProjectId = urlSearchParams.get('projectId')
    const orderItemIdInUrl = urlSearchParams.get('OrderItemId')
    const persistedProjectId = getPersistedProjectId()
    const [adobeProjectId, setAdobeProjectId] = useState(() => urlProjectId || persistedProjectId)
    const [clearedManually, setClearedManually] = useState(false)
    const [isEditFromCart, setIsEditFromCart] = useState(false)

    // Detect "edit from cart" — OrderItemId in URL AND that item is in the cart
    useEffect(() => {
        if (!orderItemIdInUrl) return
        UStoreProvider.api.orders.getCartInfo()
            .then((resp) => {
                const inCart = (resp?.Items || []).some((item) => item.OrderItemID === orderItemIdInUrl)
                if (inCart) setIsEditFromCart(true)
            })
    }, [orderItemIdInUrl])

    // When edit-from-cart is detected, drop the Adobe project so the local Replace button takes over
    useEffect(() => {
        if (!isEditFromCart) return
        setAdobeProjectId(null)
        if (window.UStoreProvider.state.customState.get("externalImageLoaded")) {
            window.UStoreProvider.state.customState.delete("externalImageLoaded")
        }
        setDropZoneHidden(false)
    }, [isEditFromCart])

    // Update adobeProjectId when properties load after initial render
    useEffect(() => {
        if (isEditFromCart) return
        if (!adobeProjectId && persistedProjectId && !clearedManually) {
            setAdobeProjectId(persistedProjectId)
        }
    }, [persistedProjectId])
    const [showRecoveryPrompt, setShowRecoveryPrompt] = useState(false)

    // Set externalImageLoaded so UploadDocumentButton hides
    useEffect(() => {
        if (isEditFromCart) return
        if (adobeProjectId && !window.UStoreProvider.state.customState.get("externalImageLoaded")) {
            window.UStoreProvider.state.customState.set("externalImageLoaded", true)
        }
    }, [adobeProjectId])

    const loadAdobePreview = async () => {
        try {
            if (!orderItem?.ID || previewLoadingFlag) return
            previewLoadingFlag = true
            const freshOrderItem = await UStoreProvider.api.orders.getOrderItem(orderItem.ID)
            if (freshOrderItem?.DocumentInfo) {
                const previewUrl = `${product.Proof.Url}&orderitemid=${orderItem.ID}`
                const metaData = freshOrderItem.DocumentInfo.MetaData
                setViewerState((prev) => ({
                    ...prev,
                    previewUrl,
                    metaData,
                    pageNumber: 1,
                    totalPageNumber: metaData.NumberOfPages,
                    realSize: `${metaData.Width}X${metaData.Height}`
                }))
                setDocumentLoaded(true)
            } else {
                // Upload didn't happen (e.g. session expired) — show recovery prompt
                setShowRecoveryPrompt(true)
            }
        } catch (err) {
            console.error('Failed to load Adobe preview:', err)
        } finally {
            previewLoadingFlag = false
        }
    }

    useEffect(() => {
        setDropZoneHidden(isEditFromCart ? false : !configState.showFileUpload)

        // Detect return from AdobeHandler — clean up URL params
        if (urlProjectId) {
            if (!documentLoaded) {
                loadAdobePreview()
            }
            const params = new URLSearchParams(window.location.search)
            params.delete('projectId')
            params.delete('propertyID')
            params.delete('userID')
            const newSearch = params.toString()
            const newUrl = window.location.pathname + (newSearch ? '?' + newSearch : '')
            window.history.replaceState(null, '', newUrl)
        }
    }, [config])

    // Retry loading preview once orderItem becomes available (return from Adobe or page reload with persisted projectId)
    useEffect(() => {
        if (isEditFromCart) return
        if (adobeProjectId && orderItem?.ID && !documentLoaded) {
            loadAdobePreview()
        }
    }, [orderItem?.ID, adobeProjectId])

    const redirectToAdobe = async (externalId) => {
        try {
            if (pushPropertiesToServer) {
                await pushPropertiesToServer()
            }
            const body = {}
            if (configState["Adobe API key"]) body.ClientId = configState["Adobe API key"]
            if (configState['Name']) body.AppName = configState['Name']
            if (externalId) body.ExternalID = externalId
            let redirectUrl = await UStoreProvider.api.orders.getAdobeRedirectUrl(orderItem.ID, propertyID, body)

            const handlerOverride = configState['Adobe Handler URL override']
            if (handlerOverride) {
                const parsed = new URL(redirectUrl)
                const override = new URL(handlerOverride)
                parsed.protocol = override.protocol
                parsed.host = override.host
                parsed.pathname = override.pathname
                const apiOverride = configState['API Base URL override']
                if (apiOverride) {
                    parsed.searchParams.set('apiBaseURL', apiOverride)
                }
                redirectUrl = parsed.toString()
            }
            window.location.href = redirectUrl
        } catch (err) {
            console.error('Failed to get Adobe redirect URL:', err)
        }
    }

    const createEditor = async () => {
        await redirectToAdobe()
    }

    const edit = async () => {
        if (!adobeProjectId) return
        await redirectToAdobe(adobeProjectId)
    }

    const continueDesign = async () => {
        setShowRecoveryPrompt(false)
        await redirectToAdobe(adobeProjectId)
    }

    const dismissRecovery = () => {
        setShowRecoveryPrompt(false)
        setAdobeProjectId(null)
        window.UStoreProvider.state.customState.delete("externalImageLoaded")
    }

    const clearPreview = async (e, clearBeforeUpdate) => {
        pdfLoader.clear()
        setUploadError(true)
        setDocumentLoaded(false)
        setDefault()
        setAdobeProjectId(null)
        setClearedManually(true)
        previewLoadingFlag = false
        if (!clearBeforeUpdate) {
            window.UStoreProvider.state.customState.delete("externalImageLoaded")
            setDropZoneHidden(false)
        }
        let fileAttachmentPropData = Object.values(properties).find((prop) => prop?.custom?.code === 'FileAttachment')
        if (fileAttachmentPropData?.value) {
            fileAttachmentPropData = JSON.parse(fileAttachmentPropData.value)
        }
        const deleteFileName = fileAttachmentPropData && fileAttachmentPropData[0] && fileAttachmentPropData[0].FileName
        const fileURIToDelete = deleteFileName && `fileNames=${encodeURIComponent(deleteFileName)}`
        deleteFileName && await UStoreProvider.api.orders.deleteFiles(orderItem.ID, propertyID, fileURIToDelete)
        onFormChange(propertyKey, [], [])
    }

    if (isAdobeExpressHidden) return null

    if (showRecoveryPrompt && adobeProjectId) {
        return (
            <div className={'adobe-widget-recovery'} role="alert">
                <p>{context.t('AdobeExpress.RecoveryPromptText')}</p>
                <div className={'adobe-widget-buttons'}>
                    <button onClick={dismissRecovery} className={'button button-secondary'}>{context.t('AdobeExpress.RecoveryCancelText')}</button>
                    <button onClick={continueDesign} className={'button button-primary'}>{context.t('AdobeExpress.RecoveryTryAgainText')}</button>
                </div>
            </div>
        )
    }

    if (documentLoaded && adobeProjectId) {
        return (
            <div className={'adobe-widget-buttons'}>
                <button onClick={clearPreview} className={'adobe-clear button button-secondary'}>{configState['Clear Button Text']}</button>
                <button onClick={edit} className={'adobe-edit button button-primary'}>{configState['Edit Button Text']}</button>
            </div>
        )
    }

    if (!documentLoaded && !adobeProjectId) {
        return (
            <div className={`adobe-widget ${!configState.showFileUpload ? 'full-size' : ''}`}>
                <AdobeLogo width={73} height={71} className="adobe-logo" onClick={createEditor}/>
                <button className={'create-button button button-primary'} onClick={createEditor}>{configState['Button Text']}</button>
                <div className={'subtitle-text'}>{configState['Subtitle text']}</div>
            </div>
        )
    }

    return null
}

export default IndexWidget
