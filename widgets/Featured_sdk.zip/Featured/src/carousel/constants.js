export const boxAnimations = {
  1: 'xw-featured-fade-in-effect',
  2: 'xw-featured-opacity-effect',
  3: 'xw-featured-breathing-effect',
}
