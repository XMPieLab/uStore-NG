export const topMiddleLocationAnimation = {
  1: 'effect-bubba',
  2: 'effect-ruby',
  3: 'effect-sarah',
}

export const borderHighlightingEffect = 1
export const bounceTopEffect = 2
export const trackingInContractEffect = 3
