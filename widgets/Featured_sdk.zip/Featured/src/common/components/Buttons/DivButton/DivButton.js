import React from 'react'

import './DivButton.css'

export function DivButton( props ) {
  const { children, className, style } = props

  return (
    <div
      className={`xw-featured-button-cta ${className}`}
      role="button"
      style={style}
      tabIndex={0}
    >
      { children }
    </div>
  )
}

DivButton.defaultProps = {
  className: '',
  style: {},
}
