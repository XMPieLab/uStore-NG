import { CarouselContainer } from '../../carousel/containers/CarouselContainer.js'
import { GridContainer } from '../../grid/containers/GridContainer.js'

export const layouts = {
  carousel: CarouselContainer,
  grid: GridContainer,
}
