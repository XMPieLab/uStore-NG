const webpack = require('webpack')
const ducConfig = require('../webpack.config')
const glob = require('glob-promise')
const path = require('path')
const fs = require('fs')
const { rm } = require('fs/promises')
const archiver = require('archiver')
const clc = require("cli-color")

const relpath = path.join.bind(path, __dirname)
const themeConfig = require(relpath('../config.json'))
const buildNumber = themeConfig.uStoreVersion

const webpackAsync = async (config) => {
  return new Promise((resolve, reject) => {
    webpack(ducConfig, (err, stats) => {
      if (stats.hasErrors()) {
        reject(stats.compilation.errors)
        return
      }
      resolve()
    });
  })
}

const buildLibrary = async (file, libraryName) => {
  ducConfig.output.filename = `../dist/${file}`
  ducConfig.entry = `./${file}`
  ducConfig.mode = 'production'
  ducConfig.output = {
    filename: `main.min.js`,
    path: `${path.resolve(__dirname, '../dist')}/${libraryName}`,
    library: libraryName,
    assetModuleFilename: `assets/[hash][ext][query]`
  }
  console.log(clc.green('\tBuild library'))
  try {
    await webpackAsync(ducConfig)
  } catch (err) {
    console.error(err)
  }
}

const createJsonConfig = (file) => {
  console.log(clc.green('\tCreate config.json'))
  const scriptContent = fs.readFileSync(file, 'utf-8')
  const matches = scriptContent.match(/window\.uStoreDucs\.push\((?<config>\{[\s\S]*?\})\s*\)/)

  let ducConfig

  if (matches && matches.groups) {
    const objectContent = matches.groups.config
    const config = objectContent.replace(/,?\s*component\s*:\s*\w+\s*/,'')
    eval(`ducConfig=${config}`)

    if (!ducConfig.name.trim() || !ducConfig.displayName.trim()) {
      const fieldName = ducConfig.name.trim() ? 'name' : 'displayName'
      console.error(clc.red(`'${fieldName}' field in DUC config must not be an empty string`))
      console.error(clc.red(matches[1]))
      process.exit(1)
    }

    return {
      engineVersion: "1",
      uStoreVersion: buildNumber,
      widgetName: ducConfig.name,
      displayName : ducConfig.displayName,
      displayNames: ducConfig.displayNames,
      configSample: ducConfig.configSample || {},
    }
  }
  return {}
}

const createJSONFile = (config, libraryName) => {
  console.log(clc.green('\tWrite config.json'))
  fs.writeFileSync(relpath(`../dist/${libraryName}/config.json`), JSON.stringify(config, null, '  '))
}

const archiveLibrary = async (libraryName) => {
  if (!fs.existsSync(`${relpath('../')}/thumbnail.png`)) {
    console.log(clc.red('\tError: thumbnail.png does not exist, please add it to the root of the project'))
    process.exit(1)
  }

  console.log(clc.green('\tCreating ZIP'))
  const output = fs.createWriteStream( `${relpath('../dist')}/${libraryName}.zip` );
  const archive = archiver('zip', {
    zlib: { level: 9 } // Sets the compression level.
  });
  archive.on('warning', function(err) {
    if (err.code === 'ENOENT') {
      console.warn(err)
    } else {
      throw err;
    }
  });

  archive.on('error', function(err) {
    throw err;
  });
  if (fs.existsSync(`${relpath('../')}/thumbnail.png`)) {
    console.log(clc.green('\tAdding thumbnail.png'))
    archive.file(`${relpath('../')}/thumbnail.png`, { name: 'thumbnail.png' })
  }
  archive.pipe(output);
  archive.glob('**', {cwd:`${relpath('../dist')}/${libraryName}` });

  await archive.finalize();
}

const deleteBuildLibrary = async (libraryName) => {
  console.log(clc.green('\tRemoving build library'))
  await rm(`${relpath('../dist')}/${libraryName}`, { recursive: true, force: true })
}

const main = async () => {
  const files = await glob('*.duc.js')
  for (let file of files) {
    const libraryName = file.replace(/\.duc\.js$/, '')
    console.log(clc.yellow('Building DUC', libraryName))
    await buildLibrary(file, libraryName)
    const config = createJsonConfig(file)
    createJSONFile(config, libraryName)
    await archiveLibrary(libraryName)
    await deleteBuildLibrary(libraryName)
  }
}


main()
