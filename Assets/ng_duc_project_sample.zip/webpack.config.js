const path = require('path')
const MiniCssExtractPlugin = require('mini-css-extract-plugin')


module.exports = {
  mode: 'development',
  devtool: 'source-map',
  entry: './___ENTRY_NAME___',
  output: {
    path: `${path.resolve(__dirname, '../dist_dev')}/___LIBRARY_NAME___`,
    filename: 'main.min.js',
    library: '___LIBRARY_NAME___',
    assetModuleFilename: 'assets/[hash][ext][query]'
  },
  externals: {
    react: 'React',
    'react-dom': 'ReactDOM',
    'prop-types': 'PropTypes'
  },
  plugins: [new MiniCssExtractPlugin()],
  module: {
    rules: [
      {
        test: /\.js?$/,
        use: [
          {
          loader: "babel-loader",
        }
        ]
      },
      {
        test: /assets[\\/]icons[\\/].*\.svg$/,
        use: [
          {
            loader: '@svgr/webpack',
            options: {
                icon: true
              },
            }
        ],
      },
      {
        test: /assets[\\/]images[\\/].*\.svg$/,
        use: [ '@svgr/webpack', 'url-loader' ],
      },
      {
        test: /assets.*\.(png|gif|jpg|jpeg)?$/,
        type: 'asset/resource'
      },
      {
        test: /assets.*\.(eot|otf|woff|woff2|ttf)?$/,
        type: 'asset/resource',
        exclude: /bootstrap|static/
      },
      {
        test: /\.(css|scss)$/,
        use: [

          {
            loader: MiniCssExtractPlugin.loader
          },
          "css-loader",
          "sass-loader",
        ],
      }

    ]
  }
};

