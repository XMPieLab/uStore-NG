import './Footer.scss'
import urlGenerator from '$ustoreinternal/services/urlGenerator'

/**
 * This component represents the footer in the store
 */
const Footer = () => {
  return (
    <div className="footer">
      <div className="main">
        <ul className="list">
          <li className="header">GENERAL INFORMATION</li>
          <li>ORGANIZATION CHART</li>
          <li>COMPANY PHONEBOOK</li>
          <li>HOLIDAY SCHEDULE</li>
          <li>CAREERS</li>
        </ul>
        <ul className="list">
          <li className="header">USEFUL LINKS</li>
          <li>
            <a href={urlGenerator.get({page:"policy"})}>LOAN POLICY PAGE</a>
          </li>
          <li>FAQS</li>
          <li>GDPR COMPLIANCE</li>
          <li>INTRANET BASICS</li>
        </ul>
      </div>
    </div>
  )
}

export default Footer
