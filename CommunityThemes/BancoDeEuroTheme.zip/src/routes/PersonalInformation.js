import { Legacy } from './Legacy'

// Example for routing <domain>/en-US/1/personal-information
export default class PersonalInformation extends Legacy {
}
