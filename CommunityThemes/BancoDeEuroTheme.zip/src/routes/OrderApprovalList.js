import { Legacy } from './Legacy'

export default class OrderApprovalList extends Legacy {
}
