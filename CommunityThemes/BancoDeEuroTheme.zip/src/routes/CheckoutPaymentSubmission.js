import { Legacy } from './Legacy'

// Example for routing <domain>/en-US/1/checkout-payment-submission
export default class CheckoutPaymentSubmission extends Legacy {
}
