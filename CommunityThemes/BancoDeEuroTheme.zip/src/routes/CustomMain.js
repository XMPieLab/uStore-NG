import { Legacy } from './Legacy'

export default class CustomMain extends Legacy {
}
