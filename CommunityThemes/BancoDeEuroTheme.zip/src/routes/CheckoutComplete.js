import { Legacy } from './Legacy'

export default class CheckoutComplete extends Legacy {
}
