import { Legacy } from './Legacy'

export default class Product extends Legacy {
}
