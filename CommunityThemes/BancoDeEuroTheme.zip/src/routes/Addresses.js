import { Legacy } from './Legacy'

// Example for routing <domain>/en-US/1/addresses
export default class Addresses extends Legacy {
}
