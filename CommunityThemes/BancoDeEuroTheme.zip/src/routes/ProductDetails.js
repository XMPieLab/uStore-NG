import { Legacy } from './Legacy'

export default class ProductDetails extends Legacy {
}
