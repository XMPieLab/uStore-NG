import { Legacy } from './Legacy'

export default class Recipient extends Legacy {
}
