import { Legacy } from './Legacy'

export default class Products extends Legacy {}
