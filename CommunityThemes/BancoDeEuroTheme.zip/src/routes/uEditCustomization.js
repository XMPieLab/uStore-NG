import { Legacy } from './Legacy'

export default class UeditCustomization extends Legacy {}
