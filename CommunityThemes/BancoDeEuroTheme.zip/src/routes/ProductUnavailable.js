import { Legacy } from './Legacy'

// Example for routing <domain>/en-US/1/cart
export default class ProductUnavailable extends Legacy {
}
