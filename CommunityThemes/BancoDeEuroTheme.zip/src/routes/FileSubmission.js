import { Legacy } from './Legacy'

export default class FileSubmission extends Legacy {
}
