import { Legacy } from './Legacy'

export default class SplitShippingAddresses extends Legacy {}
