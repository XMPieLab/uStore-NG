import {UStoreProvider} from '@ustore/core'
import Layout from '../components/Layout'
import './Category.scss'
import Slider from '$core-components/Slider'
import CategoryItem from '../components/CategoryItem'
import ProductItem from '../components/ProductItem'
import urlGenerator from '$ustoreinternal/services/urlGenerator'
import Gallery from '$core-components/Gallery'
import {t} from '$themelocalization'
import theme from '$styles/_theme.scss'
import {throttle} from 'throttle-debounce'
import { Component } from 'react'

/**
 * This is the category page
 * URL : http://<store-domain>/{language-code}/category/{category friendly ID}/
 *
 * @param {object} state - the state of the store
 */
class Category extends Component {

  constructor (props) {
    super(props)

    this.state = {
      isMobile: false
    }
  }

  componentDidMount () {
    window.addEventListener('resize', this.onResize.bind(this));
    throttle(250, this.onResize);					// Call this function once in 250ms only

    this.onResize()
  }

  componentWillUnmount() {
    window.removeEventListener('resize', this.onResize)
  }

  onResize(){
    this.setState({isMobile: document.body.clientWidth < parseInt(theme.md.replace('px', ''))})
  }

  render() {
    const { customState: {categoryFeaturedProducts, subCategories, currentCategory}} = this.props

    return (

      <Layout {...this.props} className="category">

        <div className="title">{currentCategory && currentCategory.Name}</div>

        {subCategories && subCategories.length > 0 &&
        <div>
          <div className="categories-wrapper">
            <Slider multi>
              {
                subCategories.map((model) => {
                    const page = model.HasSubCategories ? 'category' : 'products'
                    return <CategoryItem key={model.ID} model={model}
                                         url={urlGenerator.get({page: page, id: model.FriendlyID})}/>
                  }
                )
              }
            </Slider>
          </div>

          {currentCategory && categoryFeaturedProducts && categoryFeaturedProducts.length > 0 &&
          <div>
            <div className="divider"/>
            <div className="featured-products-wrapper">
              <Gallery title={t('General.FeaturedProducts')}
                       seeAllUrl={urlGenerator.get({page: 'products', id: currentCategory.FriendlyID})}
                       gridRows="4">
                {
                  categoryFeaturedProducts.map((model) => {
                    const hideProduct =
                      this.state.isMobile &&
                      model.Attributes &&
                      model.Attributes.find(attr => attr.Name === 'UEditEnabled' && attr.Value === 'true') !== undefined

                    return !hideProduct &&
                      <ProductItem
                        key={model.ID}
                        model={model} detailed
                        productNameLines="2"
                        descriptionLines="4"
                        url={urlGenerator.get({page: 'product', id: model.FriendlyID})}
                      />
                  })
                }
              </Gallery>
            </div>
          </div>
          }

        </div>
        }

      </Layout>
    )
  }
}

Category.getInitialProps = async (ctx) => {
  const {query: { id: categoryFriendlyID}} = ctx
  let {currentCategory} = UStoreProvider.state.customState.get()

  if (!currentCategory || categoryFriendlyID !== currentCategory.FriendlyID.toString()) {
    const categoryID = await UStoreProvider.api.categories.getCategoryIDByFriendlyID(categoryFriendlyID)
    currentCategory = await UStoreProvider.api.categories.getCategory(categoryID)
    const {Categories: subCategories} = await UStoreProvider.api.categories.getSubCategories(categoryID)
    const {Products: categoryFeaturedProducts} = await UStoreProvider.api.products.getProducts(categoryID, 1)
    return {
      categoryFeaturedProducts,
      currentCategory,
      subCategories
    }
  }
}

export default Category
