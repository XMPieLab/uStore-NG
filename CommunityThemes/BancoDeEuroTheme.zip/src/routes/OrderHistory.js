import { Legacy } from './Legacy'

// Example for routing <domain>/en-US/1/order-history
export default class OrderHistory extends Legacy {
}
