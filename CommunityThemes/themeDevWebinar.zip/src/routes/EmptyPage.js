import { Legacy } from './Legacy'

export default class EmptyPage extends Legacy {
}
