import { Legacy } from './Legacy'

export default class ClearingUnknownOrder extends Legacy {
}
