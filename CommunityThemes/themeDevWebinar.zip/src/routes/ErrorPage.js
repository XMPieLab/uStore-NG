import { Legacy } from './Legacy'

export default class ErrorPage extends Legacy {
}
