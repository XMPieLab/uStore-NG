import { Legacy } from './Legacy'

export default class SplitShippingItems extends Legacy {}
