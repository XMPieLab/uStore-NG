import { Legacy } from './Legacy'

export default class Drafts extends Legacy {
}
