const fse = require('fs-extra')
const theme = process.env.THEME_PAGES || 'AquaBlue'
const path = require('path')
const relpath = path.join.bind(path, __dirname)

fse.copySync(relpath(`../../themes/${theme}/assets/`), relpath('../../out/assets/'))
fse.copySync(relpath(`../../ustore-internal/static/`), relpath('../../out/static-internal/'))
