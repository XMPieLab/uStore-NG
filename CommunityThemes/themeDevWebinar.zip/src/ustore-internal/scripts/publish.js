const fs = require('fs')
const fse  = require('fs-extra')
const util = require('util')
const exec = util.promisify(require('child_process').exec)
const path = require('path')
const archiver = require('archiver')
const compileSharedScss = require('./compileSharedScss')
const relpath = path.join.bind(path, __dirname)

const argv = (str) => {
  const idx = process.argv.findIndex((a) => a.startsWith(str))
  if (idx > -1) {
    return process.argv[idx].substring(str.length + 1)
  }
  return null
}

const serverCssFileToTCompile = [ {
  file: `./styles/fonts.scss`,
  outFile: 'fonts.css'
},
  {
    file: `./styles/variables.scss`,
    outFile: 'variables.css'
  },
]

const zipIncludedFiles = [
  {type: 'directory', name: '/src/ustore-internal'},
  {type: 'directory', name: '/src/assets'},
  {type: 'directory', name: '/src/styles'},
  {type: 'directory', name: '/src/components'},
  {type: 'directory', name: '/src/core-components'},
  {type: 'directory', name: '/src/out'},
  {type: 'directory', name: '/src/pages'},
  {type: 'directory', name: '/src/routes'},
  {type: 'directory', name: '/src/scripts'},
  {type: 'directory', name: '/src/services'},
  {type: 'directory', name: '/src/static'},
  {type: 'directory', name: '/src/localizations/'},
  {type: 'directory', name: '/src/npm_packages'},
  {type: 'directory', name: '/skin'},
  {type: 'file', name: '/src/next.config.js'},
  {type: 'file', name: '/src/package.json'},
  {type: 'file', name: '/src/routes.js'},
  {type: 'file', name: '/src/server.config.js'},
  {type: 'file', name: '/src/server.js'},
  {type: 'file', name: '/src/.babelrc'},
  {type: 'file', name: '/src/.eslintrc'},
  {type: 'file', name: '/src/.gitignore'},
  {type: 'file', name: '/src/.npmrc'},
  {type: 'file', name: '/thumbnail.png'}
]

const parseVariables = async (variableFilePath, configFilePath, themeName,themeDisplayName) => {
  let variableFile = await fse.readFile(variableFilePath,'utf8')
  //get the content of the curly braces
  variableFile = variableFile.match(/{([^}]*)}/)[1]
  //Eliminate comments
  variableFile = variableFile.replace(/\/\*[\s\S]*?\*\/|([^:]|^)\/\/.*$/g,'')
  //Eliminate \t\n\r
  variableFile = variableFile.replace(/[\r,\n,\t]/g,'')
  let variablesJson = {}
  variableFile.split(';').forEach((variable) => {
    const variableName = variable.split(':')[0]
    const variableValue = variable.split(':')[1]
    if(variableName && variableValue){
      variablesJson[variableName] = variableValue.replace(/'/g,'').trim()
    }
  })
  const config = await fse.readJson(configFilePath)

  if(!config.customization) throw "Customization section does not exists in config file"
  config.customization.variables = config.customization.variables.map((variable) => {
    variable.defaultValue = variablesJson[variable.cssVariableName] ? variablesJson[variable.cssVariableName] : variable.defaultValue
    return variable
  })

  config.name = themeName
  config.displayName = themeDisplayName

  return JSON.stringify(config, null, '  ')
}

// execute shell command
const execCommandInTheme = async (command) => {
  console.log(`executing command ${command}`)
  const { stdout, stderr } = await exec(`${command}`)
  console.log(`done command ${command}`)
  console.log(stdout)
  if (stderr) {
    console.error(stderr)
  }
}

const changeAssetPrefix = async (themeName) => {
  const content = fse.readFileSync('./next.dev.config.js', 'utf8')
  const regex = /ustorethemes(\/)[a-zA-Z0-9]*/i
  return content.replace(regex, `ustorethemes/${themeName}`)
}

// commands to compile a library
const publishLib  = async (themeName,themeDisplayName) => {
  console.log(`deleting out directory`)
  fse.removeSync(`./out`)

  console.log(`deleting .next directory`)
  fse.removeSync(`./.next`)

  console.log(`change next.dev.config.js assetPrefix value to theme name`)
  const nextDevWithAssetPrefix = await changeAssetPrefix(themeName)
  fs.writeFileSync('./next.publish.config.js', nextDevWithAssetPrefix)

  console.log(`change package.json customization section from variables.scss`)
  const configJsonWithParsedVars = await parseVariables(`../src/styles/variables.scss`,`../config.json`, themeName, themeDisplayName)

  console.log(`exporting library`)
  const commands = [ 'npm run export']
  for (const cmd of commands) {
    await execCommandInTheme(cmd, themeName)
  }

  fse.ensureDirSync(relpath('../../out/assets/'))
  fse.ensureDirSync(relpath('../../out/static-internal/'))

  console.log('copying assets')
  fse.copySync(relpath(`../../assets/`), relpath('../../out/assets/'))

  console.log('copying ustore-internal/static')
  fse.copySync(relpath(`../../ustore-internal/static`), relpath('../../out/static-internal/'))

  console.log('compiling shared css files')
  await compileSharedScss(serverCssFileToTCompile, relpath(`../../out/assets`))

  console.log(`Zip theme directory ${__dirname}/${themeName}.zip`)
  const output = fs.createWriteStream(`../../${themeName}.zip`);

  const archive = archiver('zip', {
    zlib: { level: 9 } // Sets the compression level.
  });
  archive.pipe(output);
  zipIncludedFiles.forEach(d => {
    const p = path.join(__dirname, '../../..' + d.name)

    if (fs.existsSync(p)) {
      console.log('packing', d.name)
      if (d.type === 'directory') {
        archive.directory(p, d.name, {});
      } else {
        archive.file(p, {name: d.name});
      }
    }
  })

  archive.append(nextDevWithAssetPrefix, {name:'/src/next.dev.config.js'})
  archive.append(configJsonWithParsedVars, {name:'/config.json'})
  archive.finalize();

  console.log('Delete temporary config file (next.publish.config.js)')
  fse.removeSync('./next.publish.config.js')
}

const nameArg = argv('name')
const displayNameArg = argv('displayName')

if (nameArg || displayNameArg) {
  if (!nameArg) {
    console.error('Error: package name is required.\n')
    process.exit(1)
  }

  if (!/^[a-zA-Z0-9_]{0,20}$/.test(nameArg)) {
    console.error('Error: Package name field can contain up to 20 characters which include letters, numbers and underscore.\n')
    process.exit(1)
  }

  if (!displayNameArg) {
    console.error('Error: displayName parameter is required.\n')
    process.exit(1)
  }

  publishLib(nameArg, displayNameArg)
} else {
  console.error('Error: Both name and display name arguments are required')
}
