(function() {

    const queryOrCookieStrToObj = (str) =>  {
      if (str && str !== '') {
        return JSON.parse('{"' +
          str
            .replace(/^(.*)\?/, '')
            .split(/[&;]\s?/g)
            .map(keyval => keyval.replace(/=/, '":"'))
            .join('","')
          + '"}', function (key, value) {
          return key === "" ? value : decodeURIComponent(value)
        })
      }
      return {}
    }

    var search = location.search.substring(1);
    var queryParams = queryOrCookieStrToObj(search)

    var cookieParams = {};
    document.cookie && document.cookie.split(/\s*;\s*/).forEach(function(pair) {
      pair = pair.split(/\s*=\s*/);
      cookieParams[pair[0]] = pair.splice(1).join('=');
    });

    if (queryParams.StoreGuid) {
      cookieParams._storeID = queryParams.StoreGuid
      document.cookie = "_storeID=" + queryParams.StoreGuid
    }

    var storeID = queryParams.StoreGuid || cookieParams._storeID
    var status = queryParams.ShowThemeAsDraft && queryParams.ShowThemeAsDraft.toLowerCase() === 'true' ? 'Draft' : 'Published'

    document.writeln('<link rel="stylesheet" href="' + '/uStoreThemeCustomizations/' + storeID + '/' + status + '/Css/variables.css?rand=' + Math.random() +'"/>')
    document.writeln('<link rel="stylesheet" href="' + '/uStoreThemeCustomizations/' + storeID + '/' + status + '/Css/Custom.css?rand=' + Math.random() +'"/>')
    document.writeln('<link rel="stylesheet" href="' + '/uStoreThemeCustomizations/' + storeID + '/' + status + '/Css/fonts.css?rand=' + Math.random() +'"/>')
  }
)()
