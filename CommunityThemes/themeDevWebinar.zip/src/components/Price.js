/**
 * A component to display price information of a product, formatted according to currency and culture definitions
 *
 * @param {object} model - ProductPriceModel containing data regarding the price of the product
 * @param {object} state - current state of the store
 */

import {withState} from '$ustoreinternal/services/withState'
import {UStoreProvider} from '@ustore/core'

const Price = ({model, state}) => {
  const {currentStore, currentCurrency, currentCulture} = state

  if (!model || Number.isNaN(model.Price) || Number.isNaN(model.Tax))
    return ''

  let formatParams = {
    taxFormat: currentStore.TaxFormat,
    symbol: currentCurrency.Symbol,
    code: currentCurrency.Code,
    currencyFormat: currentCulture.CurrencyFormat,
    decimalSeparator: currentCulture.DecimalSeparator,
    decimalPlaces: currentCulture.DecimalPlaces
  }

  const {price, tax, priceIncludingTax} = UStoreProvider.state.culture.getConvertedPrices(model)

  //format the given price and tax amount to a string according to the tax, culture and currency definitions of models in state
  const priceDisplayString = formatParams.taxFormat
      .replace(/{Price}/g, formatForCurrencyAndCulture(price, formatParams))
      .replace(/{Tax}/g, formatForCurrencyAndCulture(tax, formatParams))
      .replace(/{PriceIncludingTax}/g, formatForCurrencyAndCulture(priceIncludingTax, formatParams))

  return (
    <span className="price">{priceDisplayString} {formatParams.code}</span>
  )
}

//format the given amount to a string according to the passed definitions of currency an culture
const formatForCurrencyAndCulture = (amount, formatParams) => {
  const {currencyFormat, symbol, decimalPlaces, decimalSeparator} = formatParams
  return currencyFormat
    .replace(/{Symbol}/g, symbol)
    //format the given amount to a string according to passed culture definitions
    .replace(/{Amount}/g, amount.toFixed(decimalPlaces).replace('.', decimalSeparator))
}

export default withState(Price)
